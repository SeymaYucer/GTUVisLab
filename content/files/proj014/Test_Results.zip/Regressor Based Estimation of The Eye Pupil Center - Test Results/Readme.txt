A compressed test results file contains a statistics file and a test results 
folder. 

Statistics file format
----------------------
Statistics file that's name is Statistics.txt, contains test results and errors 
for all images tested. For each image, there are 9 lines of info:

Line 1:  Image name
Line 2:  Ground truth left eye center
Line 3:  Test result left eye center
Line 4:  Left eye center error in pixels
Line 5:  Ground truth right eye center
Line 6:  Test result right eye center
Line 7:  Left eye right error in pixels
Line 8:  Computed normalized error
Line 9:  Seperator

Test Results folder
-------------------
This folder contains test result images of our regressor. There are three 
different test result images for each image. In BioID dataset, we tested 1519 
images so the folder contains 4557 images, in CAVE dataset we have tested 
300 images so the folder contains 900 images.

Image Definitions
-----------------
Original Image:	The tested area of the image. File names for original images 
ends with "_Original.png".

Score Image: The regressor results of the tested area of the image. File names 
for score images ends with "_Score.png".

Result Image: Marked test results of image. Plus lines show the ground truth 
and cross lines show the estimated pupil center. Files names for result images 
ends with "_Result.jpg".